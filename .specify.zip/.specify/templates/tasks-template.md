# Tasks — [FEATURE_NAME]

**Feature**: [FEATURE_NAME]
**Sprint / Milestone**: [MILESTONE]
**Generated**: [DATE]

---

## Legend

- `[ ]` To do
- `[/]` In progress
- `[x]` Done
- **Priority**: P0 (blocker) | P1 (important) | P2 (nice-to-have)
- **Type**: `[BE]` Backend | `[FE]` Frontend | `[AI]` AI integration | `[DB]` Database | `[TEST]` Testing | `[INFRA]` Infrastructure

---

## Task List

### 1. Foundation (Dependencies first)

- [ ] [DB-1] [P0] [Task description] — _Principle P[N]_
- [ ] [BE-1] [P0] [Task description] — _Principle P[N]_

### 2. Backend / API

- [ ] [BE-2] [P0] [Task description] — _Principle P[N]_
- [ ] [AI-1] [P0] Configure OpenRouter model selection endpoint — _Principle P1_

### 3. Frontend / UI

- [ ] [FE-1] [P0] [Task description] — _Principle P2 / P7_
- [ ] [FE-2] [P1] [Task description] — _Principle P4_

### 4. AI Integration

- [ ] [AI-2] [P1] Implement real-time AI content refinement with 500ms debounce — _Principle P5_

### 5. Testing & Verification

- [ ] [TEST-1] [P0] [Test description]
- [ ] [TEST-2] [P1] Verify all new components render correctly in RTL — _Principle P7_

---

## Dependency Graph

```
[DB-1] → [BE-1] → [AI-1] → [FE-1]
                 ↘ [BE-2] → [FE-2]
```

---

## Notes

[Any additional context, decisions, or constraints relevant to this task list.]
