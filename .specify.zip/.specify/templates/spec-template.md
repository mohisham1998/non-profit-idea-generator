# Feature Specification — [FEATURE_NAME]

**Feature**: [FEATURE_NAME]
**Status**: Draft | Under Review | Approved
**Date**: [SPEC_DATE]
**Author**: [AUTHOR]

---

## Summary

[One paragraph describing what this feature does and the user value it delivers.]

---

## Constitution Alignment

> List the constitution principles (`.specify/memory/constitution.md`) this feature addresses.

- **P[N] — [Principle Name]**: [How this feature implements or upholds this principle]

---

## User Stories

| ID | As a… | I want to… | So that… |
|----|-------|-----------|----------|
| US-1 | [role] | [action] | [benefit] |

---

## Functional Requirements

### Must Have (P0)
- [ ] [FR-1] [Requirement]

### Should Have (P1)
- [ ] [FR-N] [Requirement]

### Nice to Have (P2)
- [ ] [FR-N] [Requirement]

---

## Non-Functional Requirements

- **Arabic/RTL (P7)**: All UI text and layout MUST support Arabic RTL rendering.
- **Performance**: [Any latency or throughput requirements]
- **Accessibility**: [ARIA, keyboard navigation requirements]
- **Security**: [Authentication, authorization requirements]

---

## Out of Scope

[Explicitly list anything that might seem related but is NOT included in this feature.]

---

## Acceptance Criteria

- [ ] [Criterion 1 — testable, specific]
- [ ] [Criterion 2]

---

## Open Questions

| # | Question | Owner | Status |
|---|----------|-------|--------|
| 1 | [Question] | [Name] | Open/Resolved |
