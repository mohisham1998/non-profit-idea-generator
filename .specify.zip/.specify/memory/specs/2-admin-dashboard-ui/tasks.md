# Tasks — Admin Dashboard UI

**Feature**: Admin Dashboard UI
**Sprint / Milestone**: Milestone 3 (Administration)
**Generated**: 2026-02-28

---

## Legend

- `[ ]` To do
- `[/]` In progress
- `[x]` Done
- **Priority**: P0 (blocker) | P1 (important) | P2 (nice-to-have)
- **Type**: `[BE]` Backend | `[FE]` Frontend | `[AI]` AI integration | `[DB]` Database | `[TEST]` Testing | `[INFRA]` Infrastructure

---

## Task List

### Phase 1: Setup & Foundation

- [ ] T001 [DB] Map User/Tenant Profile schema in PostgreSQL with `primaryColor`, `logoUrl`, `logoPlacement`, `selectedModelId`, `openRouterApiKey`, and `quotaLimitUsd`
- [ ] T002 [DB] Map Slide Deck schema in PostgreSQL with `title`, `creationDate`, `slideCount`, `thumbnailUrl`, and `tenantId`
- [ ] T003 [INFRA] Setup Tailwind CSS RTL configuration, CSS variables for theming, and Cairo font family in `tailwind.config.js` and `src/index.css`
- [ ] T004 [BE] Setup base API router structure for `/api/decks`, `/api/models`, `/api/branding`, `/api/usage` in `server/routes/api.js`
- [ ] T005 [P] [BE] Create OpenRouter API client utility for reuse across controllers in `server/utils/openrouter.js`

### Phase 2: US-7 (RTL Core Layout & Navigation)
*Goal: Provide the overall Arabic, RTL-only dashboard shell with an animated sidebar.*

- [ ] T006 [FE] [US7] Create global Zustand state store for theme and user profile data in `src/store/useStore.ts`
- [ ] T007 [FE] [US7] Create `src/layouts/AdminLayout.tsx` utilizing Framer Motion for the animated sidebar and enforcing `dir="rtl"`

### Phase 3: US-1 (Dashboard Analytical Overview)
*Goal: Display a polished summary view immediately upon login.*

- [ ] T008 [BE] [US1] Create `/api/usage/overview` endpoint to serve summary stats and recent actions in `server/controllers/usageController.js`
- [ ] T009 [FE] [US1] Create and integrate `src/pages/DashboardHome.tsx` to display summary cards, charts, and recent actions strip

### Phase 4: US-2 (Deck Library Management)
*Goal: Enable the admin to browse, open, rename, duplicate, and delete their generated decks.*

- [ ] T010 [BE] [US2] Implement CRUD endpoints (`GET/POST/PUT/DELETE /api/decks`) with duplication logic in `server/controllers/deckController.js`
- [ ] T011 [P] [FE] [US2] Create thumbnail grid/list view in `src/pages/DeckLibrary.tsx`
- [ ] T012 [FE] [US2] Build `DeckCard.tsx` component with context menu (Open, Rename inline, Duplicate as "نسخة", Delete with confirm) in `src/components/DeckCard.tsx`

### Phase 5: US-3 (AI Model Selection via OpenRouter)
*Goal: Allow selection of the specific generative AI model from a live OpenRouter list.*

- [ ] T013 [BE] [US3] Implement `/api/models` endpoint fetching and locally caching models from OpenRouter in `server/controllers/modelController.js`
- [ ] T014 [P] [FE] [US3] Create `src/pages/ModelSettings.tsx` to fetch and display the grouped model list
- [ ] T015 [FE] [US3] Implement model selection persistence in global state and handle fetch failures with the warning banner in `src/pages/ModelSettings.tsx`

### Phase 6: US-4 & US-5 (Branding Customization)
*Goal: Let admins upload logos and pick primary thematic colors.*

- [ ] T016 [BE] [US4] Implement `/api/branding` endpoint handling 2MB max image uploads and color/placement updates in `server/controllers/brandingController.js`
- [ ] T017 [P] [FE] [US4] Create `src/pages/BrandingSettings.tsx` with logo upload UI and placement radio toggles (Cover, Footer, Hidden)
- [ ] T018 [FE] [US4] Implement primary color picker (presets + hex) that dynamically updates CSS variables in `src/pages/BrandingSettings.tsx`

### Phase 7: US-6 (Usage & Quota Tracking)
*Goal: Display accurate, USD-based token usage parsed directly from OpenRouter APIs.*

- [ ] T019 [BE] [US6] Implement `/api/usage` endpoint retrieving live bill/token cost from OpenRouter via tenant key in `server/controllers/usageController.js`
- [ ] T020 [P] [FE] [US6] Create `src/pages/UsageQuota.tsx` displaying fetched usage cost vs $50.00 limits with an animated progress bar

### Phase 8: Polish, Testing & Cross-Cutting

- [ ] T021 [TEST] Write unit tests ensuring quota cost calculations match plan limits in `server/controllers/usageController.test.js`
- [ ] T022 [TEST] Write component tests validating that fallback warning banners render without network in `src/pages/ModelSettings.test.tsx`
- [ ] T023 [FE] Verify ARIA labels in Arabic and assess contrast ratios for dynamically selected primary colors across the app

---

## Dependency Graph

```
[Phase 1 Setup] T001, T002, T003, T004, T005
       ↓
[Phase 2 Frame] T006, T007
       ↓
[Phase 3 Home]  T008, T009
       ↓
[Phase 4 Decks] T010, T011, T012
       ↓
[Phase 5 Model] T013, T014, T015
       ↓
[Phase 6 Brand] T016, T017, T018
       ↓
[Phase 7 Usage] T019, T020
       ↓
[Phase 8 Test]  T021, T022, T023
```

---

## Notes

- **Parallel Execution**: Frontend and Backend tasks labeled `[P]` within User Story phases can safely be worked on by separate workflows or engineers concurrently.
- All tasks must adhere to purely `rtl` direction logic and utilize the Cairo font family as stated in FR-1, 2, and 3.
